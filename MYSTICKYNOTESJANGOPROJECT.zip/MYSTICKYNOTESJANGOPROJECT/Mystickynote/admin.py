from django.contrib import admin
from .models import Mystickynote

admin.site.register(Mystickynote)
