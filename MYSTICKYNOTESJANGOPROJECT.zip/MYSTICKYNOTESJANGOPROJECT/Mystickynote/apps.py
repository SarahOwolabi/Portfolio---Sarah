from django.apps import AppConfig


class MystickynoteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Mystickynote'
