from django.urls import path 
from .views import get_all, get, create, update, delete

urlpatterns= [
    path('', get_all, name='Mystickynote'),
    path('<int:pk>', get, name='Mystickynote'),
    path('new/', create, name='create_Mystickynote'),
    path('<int:pk>/edit', update, name='update_Mystickynote'),
    path('<int:pk>/', delete, name='delete_Mystickynote'),
]

