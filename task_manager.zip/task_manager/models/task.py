#This Task class is initialized with task_id, description, assigned_to, and status.
#task methods are create task, assign task, save task and update task

class Task:
    def __init__(self, task_id, description, assigned_to=None, status='Pending'):
        self.task_id = task_id
        self.description = description
        self.assigned_to = assigned_to
        self.status = status

    def __str__(self):
        return f"Task ID: {self.task_id}\nDescription: {self.description}\nAssigned to: {self.assigned_to}\nStatus: {self.status}\n"

    def create_task(task_id, description):
        return Task(task_id, description)

    def assign_task(self, assigned_to):
        self.assigned_to = assigned_to

    def save_task(self, filename):
        with open(filename, 'a') as file:
            file.write(str(self) + '\n')

    def update_task(self, new_description=None, new_assigned_to=None, new_status=None):
        if new_description:
            self.description = new_description
        if new_assigned_to:
            self.assigned_to = new_assigned_to
        if new_status:
            self.status = new_status

# Example Usage
task1 = Task.create_task(1, "Finish the report")
task1.assign_task("Sarah")
task1.save_task("tasks.txt")
task1.update_task(new_status="Completed")
print(task1)

task2 = Task.create_task(2, "Prepare for meeting")
task2.save_task("tasks.txt")
print(task2)

