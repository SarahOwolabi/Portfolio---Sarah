NUL not found
