

import unittest
from models.task import Task
from data.data_access import TaskFileDAL

class TestTaskManager(unittest.TestCase):

    def setUp(self):
        # This will run before each test
        self.task1 = Task(task_id='1', name='Test Task 1', description='Description 1', status='Pending')
        self.task2 = Task(task_id='2', name='Test Task 2', description='Description 2', status='Completed')
        self.dal = TaskFileDAL('test_tasks.txt')
        self.dal.save_task(self.task1)
        self.dal.save_task(self.task2)

    def tearDown(self):
        # This will run after each test
        self.dal.delete_task('1')
        self.dal.delete_task('2')

    def test_create_task(self):
        task = Task(task_id='3', name='New Task', description='New Description', status='Pending')
        self.dal.save_task(task)
        tasks = self.dal.load_tasks()
        self.assertIn(task, tasks)

    def test_assign_task(self):
        task = self.dal.load_task('1')
        task.status = 'In Progress'
        self.dal.update_task(task)
        updated_task = self.dal.load_task('1')
        self.assertEqual(updated_task.status, 'In Progress')

    def test_update_task(self):
        task = self.dal.load_task('1')
        task.name = 'Updated Task 1'
        task.description = 'Updated Description 1'
        self.dal.update_task(task)
        updated_task = self.dal.load_task('1')
        self.assertEqual(updated_task.name, 'Updated Task 1')
        self.assertEqual(updated_task.description, 'Updated Description 1')

    def test_delete_task(self):
        self.dal.delete_task('1')
        tasks = self.dal.load_tasks()
        task_ids = [task.task_id for task in tasks]
        self.assertNotIn('1', task_ids)

    def test_view_all_tasks(self):
        tasks = self.dal.load_tasks()
        self.assertEqual(len(tasks), 2)
        self.assertIn(self.task1, tasks)
        self.assertIn(self.task2, tasks)

if __name__ == '__main__':
    unittest.main()

