from models.task import Task
from data.data_access import TaskFileDAL

def display_menu():
    print("Task Manager")
    print("1. Create a new task")
    print("2. Assign a task")
    print("3. Update a task")
    print("4. Delete a task")
    print("5. View all tasks")
    print("6. Exit")

def main():
    dal = TaskFileDAL('tasks.txt')
    
    while True:
        display_menu()
        choice = input("Enter your choice: ")

        if choice == '1':
            task_id = input("Enter task ID: ")
            name = input("Enter task name: ")
            description = input("Enter task description: ")
            status = input("Enter task status: ")
            task = Task(task_id, name, description, status)
            dal.save_task(task)
            print("Task created successfully.")

        elif choice == '2':
            # For simplicity, assume assigning a task means changing its status
            task_id = input("Enter task ID to assign: ")
            tasks = dal.load_tasks()
            task = next((t for t in tasks if t.task_id == task_id), None)
            if task:
                new_status = input("Enter new status: ")
                task.status = new_status
                dal.update_task(task)
                print("Task assigned successfully.")
            else:
                print("Task not found.")

        elif choice == '3':
            task_id = input("Enter task ID to update: ")
            tasks = dal.load_tasks()
            task = next((t for t in tasks if t.task_id == task_id), None)
            if task:
                new_name = input(f"Enter new name (current: {task.name}): ") or task.name
                new_description = input(f"Enter new description (current: {task.description}): ") or task.description
                new_status = input(f"Enter new status (current: {task.status}): ") or task.status
                task.name = new_name
                task.description = new_description
                task.status = new_status
                dal.update_task(task)
                print("Task updated successfully.")
            else:
                print("Task not found.")

        elif choice == '4':
            task_id = input("Enter task ID to delete: ")
            dal.delete_task(task_id)
            print("Task deleted successfully.")

        elif choice == '5':
            tasks = dal.load_tasks()
            if tasks:
                for task in tasks:
                    print(task)
            else:
                print("No tasks found.")

        elif choice == '6':
            print("Exiting Task Manager.")
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()


