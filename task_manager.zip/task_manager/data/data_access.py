#display_menu(): This function prints the menu options for the user to interact with the task manager.

#main(): This function contains the main loop of the task manager:
#It initializes taskfiledal
#Based on the user's choice, it calls the appropriate methods to create, assign, update, delete, or view tasks.


from models.task import Task
TASKS_FILE = 'tasks.txt'


class TaskFileDAL:
    def __init__(self, filename):
        self.filename = filename

    def save_task(self, task):
        with open(self.filename, 'a') as file:
            file.write(f"{task.task_id}|{task.name}|{task.description}|{task.status}\n")

    def load_tasks(self):
        tasks = []
        try:
            with open(self.filename, 'r') as file:
                for line in file:
                    task_id, name, description, status = line.strip().split('|')
                    tasks.append(Task(task_id, name, description, status))
        except FileNotFoundError:
            pass  # No tasks saved yet
        return tasks

    def update_task(self, task):
        tasks = self.load_tasks()
        with open(self.filename, 'w') as file:
            for t in tasks:
                if t.task_id == task.task_id:
                    file.write(f"{task.task_id}|{task.name}|{task.description}|{task.status}\n")
                else:
                    file.write(f"{t.task_id}|{t.name}|{t.description}|{t.status}\n")

    def delete_task(self, task_id):
        tasks = self.load_tasks()
        with open(self.filename, 'w') as file:
            for task in tasks:
                if task.task_id != task_id:
                    file.write(f"{task.task_id}|{task.name}|{task.description}|{task.status}\n")


#Creating a Task: Prompts the user for task details and saves the task using dal.save_task().

#Assigning a Task: Finds the task by ID, prompts the user for the new status, and updates the task using dal.update_task().
#Updating a Task: Similar to assigning, but it also allows updating the name and description.
#Deleting a Task: Deletes the task by ID using dal.delete_task().
#Viewing All Tasks: Loads all tasks and prints them.
#Exiting: Exits the loop and terminates the program.
